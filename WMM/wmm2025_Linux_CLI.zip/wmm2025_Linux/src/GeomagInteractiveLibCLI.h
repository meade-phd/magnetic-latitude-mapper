#if !defined(GEOMAG_INTER_LIB_CLI)
#define GEOMAG_INTER_LIB_CLI

int  MAG_GetUserInputCLI(MAGtype_MagneticModel *MagneticModel, MAGtype_Geoid *Geoid, MAGtype_CoordGeodetic *CoordGeodetic, MAGtype_Date *MagneticDate, int argc, char* argv[]);
void MAG_GetDegCLI(char* Degree_String, double* latitude, double bounds[2]);
int  MAG_GetAltitudeCLI(char* Altitude_String, MAGtype_Geoid *Geoid, MAGtype_CoordGeodetic* coords, int bounds[2], int AltitudeSetting);

#endif
