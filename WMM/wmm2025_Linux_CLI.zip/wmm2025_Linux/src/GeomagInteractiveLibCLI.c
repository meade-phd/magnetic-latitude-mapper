#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include "GeomagnetismHeader.h"
#include "GeomagInteractiveLib.h"
#include "GeomagInteractiveLibCLI.h"


// void MAG_GetDegCLI(char* Query_String, double* latitude, double bounds[2]) {
void MAG_GetDegCLI(char* Degree_String, double* latitude, double bounds[2]) {
    /*Gets a degree value from the user using the standard input*/
    char buffer[64], Error_Message[255];
    int done, i, j;

    /*
    printf("%s", Query_String);
    while (NULL == fgets(buffer, sizeof(buffer), stdin)){
        printf("%s", Query_String);
        if (buffer[sizeof(buffer) - 1] != '\n'){
            MAG_clear_input_buffer(); // Remove the left characters from stdin if the buffer is not able to read the whole stdin
        }
    }
    */

    // strncpy(buffer, Degree_String, 64);
    strncpy(buffer, Degree_String, sizeof(buffer));

    for(i = 0, done = 0, j = 0; i < (int) sizeof(buffer) && !done; i++)
    {
        if(buffer[i] == '.')
        {
            j = sscanf(buffer, "%lf", latitude);
            if(j == 1)
                done = 1;
            else
                done = -1;
        }
        if(buffer[i] == ',')
        {
            if(MAG_ValidateDMSstring(buffer, bounds[0], bounds[1], Error_Message))
            {
                MAG_DMSstringToDegree(buffer, latitude);
                done = 1;
            } else
                done = -1;
        }
        if(buffer[i] == ' ')/* This detects if there is a ' ' somewhere in the string,
                if there is the program tries to interpret the input as Degrees Minutes Seconds.*/
        {
            if(MAG_ValidateDMSstring(buffer, bounds[0], bounds[1], Error_Message))
            {
                MAG_DMSstringToDegree(buffer, latitude);
                done = 1;
            } else
                done = -1;
        }
        if(buffer[i] == '\0' || done == -1)
        {
            if(MAG_ValidateDMSstring(buffer, bounds[0], bounds[1], Error_Message) && done != -1)
            {
                sscanf(buffer, "%lf", latitude);
                done = 1;
            } else
            {
                printf("%s", Error_Message);
                MAG_strlcpy_equivalent(buffer, "", sizeof(buffer));
                printf("\nError encountered, please re-enter as '(-)DDD,MM,SS' or in Decimal Degrees DD.ddd:\n");
                while(NULL == fgets(buffer, sizeof(buffer), stdin)) {
                    printf("\nError encountered, please re-enter as '(-)DDD,MM,SS' or in Decimal Degrees DD.ddd:\n");
                    if (buffer[sizeof(buffer) - 1] != '\n'){
                        MAG_clear_input_buffer(); // Remove the left characters from stdin if the buffer is not able to read the whole stdin
                    }
                }

                i = -1;
                done = 0;
            }
        }
    }
}

// int MAG_GetAltitudeCLI(char* Query_String, MAGtype_Geoid *Geoid, MAGtype_CoordGeodetic* coords, int bounds[2], int AltitudeSetting){
int MAG_GetAltitudeCLI(char* Altitude_String, MAGtype_Geoid *Geoid, MAGtype_CoordGeodetic* coords, int bounds[2], int AltitudeSetting){
    int done, j, UpBoundOn;
    char tmp;
    char buffer[64];
    double value;
    done = 0;
    if(bounds[1] != NO_ALT_MAX){
        UpBoundOn = TRUE;
    } else {
        UpBoundOn = FALSE;
    }
    // printf("%s", Query_String);

    while(!done)
    {
        MAG_strlcpy_equivalent(buffer, "", sizeof(buffer));
        /* while(NULL == fgets(buffer, sizeof(buffer), stdin)) {
            printf("%s", Query_String);
        } */

        // strncpy(buffer, Altitude_String, 64);   // 64 is sizeof(buffer)
        strncpy(buffer, Altitude_String, sizeof(buffer));

        j = 0;
        if((AltitudeSetting != MSLON) && (buffer[0] == 'e' || buffer[0] == 'E' || AltitudeSetting == WGS84ON)) /* User entered height above WGS-84 ellipsoid, copy it to CoordGeodetic->HeightAboveEllipsoid */
        {
                        if(buffer[0]=='e' || buffer[0]=='E') {
                                j = sscanf(buffer, "%c%lf", &tmp, &coords->HeightAboveEllipsoid);
                        } else {
                                j = sscanf(buffer, "%lf", &coords->HeightAboveEllipsoid);
                        }
            if(j == 2)
                j = 1;
            Geoid->UseGeoid = 0;
            coords->HeightAboveGeoid = coords->HeightAboveEllipsoid;
                        value = coords->HeightAboveEllipsoid;
        } else /* User entered height above MSL, convert it to the height above WGS-84 ellipsoid */
        {
            Geoid->UseGeoid = 1;
            j = sscanf(buffer, "%lf", &coords->HeightAboveGeoid);
            MAG_ConvertGeoidToEllipsoidHeight(coords, Geoid);
                        value = coords->HeightAboveGeoid;
        }
        if(j == 1)
            done = 1;
        else
            printf("\nIllegal Format, please re-enter as '(-)HHH.hhh:'\n");
        if((value < bounds[0] || (value > bounds[1] && UpBoundOn)) && done == 1) {
                        if(UpBoundOn) {
                                done = 0;
                                printf("\nWarning: The value you have entered of %f km for the elevation is outside of the required range.\n", value);
                                printf(" An elevation between %d km and %d km is needed. \n", bounds[0], bounds[1]);
                                if (AltitudeSetting == WGS84ON){
                                    printf("Please enter height above WGS-84 Ellipsoid (in kilometers):\n");
                                } else if (AltitudeSetting==MSLON){
                                    printf("Please enter height above mean sea level (in kilometers):\n");
                                } else {
                                    printf("Please enter height in kilometers (prepend E for height above WGS-84 Ellipsoid):");
                                }
                        } else {
                                switch(MAG_Warnings(3, value, NULL)) {
                                        case 0:
                                                return USER_GAVE_UP;
                                        case 1:
                                                done = 0;
                                                printf("Please enter height above sea level (in kilometers):\n");
                                                break;
                                        case 2:
                                                break;
                                }
            }
        }
    }
    return 0;
}


int MAG_GetUserInputCLI(MAGtype_MagneticModel *MagneticModel, MAGtype_Geoid *Geoid, MAGtype_CoordGeodetic *CoordGeodetic, MAGtype_Date *MagneticDate, int argc, char* argv[])

/*
This prompts the user for coordinates, and accepts many entry formats.
It takes the MagneticModel and Geoid as input and outputs the Geographic coordinates and Date as objects.
Returns 0 when the user wants to exit and 1 if the user enters valid input data.
INPUT :  MagneticModel  : Data structure with the following elements used here
                        double epoch;       Base time of Geomagnetic model epoch (yrs)
                : Geoid Pointer to data structure MAGtype_Geoid (used for converting HeightAboveGeoid to HeightABoveEllipsoid

OUTPUT: CoordGeodetic : Pointer to data structure. Following elements are updated
                        double lambda; (longitude)
                        double phi; ( geodetic latitude)
                        double HeightAboveEllipsoid; (height above the ellipsoid (HaE) )
                        double HeightAboveGeoid;(height above the Geoid )

                MagneticDate : Pointer to data structure MAGtype_Date with the following elements updated
                        int	Year; (If user directly enters decimal year this field is not populated)
                        int	Month;(If user directly enters decimal year this field is not populated)
                        int	Day; (If user directly enters decimal year this field is not populated)
                        double DecimalYear;      decimal years

CALLS: 	MAG_DMSstringToDegree(buffer, &CoordGeodetic->lambda); (The program uses this to convert the string into a decimal longitude.)
                MAG_ValidateDMSstringlong(buffer, Error_Message)
                MAG_ValidateDMSstringlat(buffer, Error_Message)
                MAG_Warnings
                MAG_ConvertGeoidToEllipsoidHeight
                MAG_DateToYear

 */
{
    char Error_Message[255];
    char buffer[40];
    buffer[sizeof(buffer) - 1] = '\0';
    int i, j, a, b, c, done = 0;

    int idex;

    double lat_bound[2] = {LAT_BOUND_MIN, LAT_BOUND_MAX};
    double lon_bound[2] = {LON_BOUND_MIN, LON_BOUND_MAX};
    int alt_bound[2] = {ALT_BOUND_MIN, NO_ALT_MAX}; 
    int Qstring_size = 1028;
    char* Qstring = malloc(sizeof(char) * Qstring_size);
    memset(Qstring, '\0', Qstring_size); 

    /* for(idex = 0; idex < argc; idex++) {
        printf("arg %i: %s\n", idex, argv[idex]);
    } */

    if (argc < 5) {
        exit(EXIT_FAILURE);
    }

    MAG_strlcpy_equivalent(Qstring, "\nPlease enter latitude\nNorth latitude positive, For example:\n30, 30, 30 (D,M,S) or 30.508 (Decimal Degrees) (both are north)\n", Qstring_size);
    // MAG_GetDegCLI(Qstring, &CoordGeodetic->phi, lat_bound);
    MAG_GetDegCLI(argv[1], &CoordGeodetic->phi, lat_bound);
    MAG_strlcpy_equivalent(buffer, "", sizeof(buffer)); /*Clear the input*/

    memset(Qstring, '\0', Qstring_size); // Clear QString to avoid show the string copied from previous time
    MAG_strlcpy_equivalent(Qstring,"\nPlease enter longitude\nEast longitude positive, West negative.  For example:\n-100.5 or -100, 30, 0 for 100.5 degrees west\n", Qstring_size);
    // MAG_GetDegCLI(Qstring, &CoordGeodetic->lambda, lon_bound);
    MAG_GetDegCLI(argv[2], &CoordGeodetic->lambda, lon_bound);

    memset(Qstring, '\0', Qstring_size);    
    MAG_strlcpy_equivalent(Qstring,"\nPlease enter height above mean sea level (in kilometers):\n[For height above WGS-84 ellipsoid prefix E, for example (E20.1)]\n", Qstring_size);
    // if(MAG_GetAltitudeCLI(Qstring, Geoid, CoordGeodetic, alt_bound, FALSE)==USER_GAVE_UP)
    if(MAG_GetAltitudeCLI(argv[3], Geoid, CoordGeodetic, alt_bound, FALSE)==USER_GAVE_UP)
        return FALSE;
    MAG_strlcpy_equivalent(buffer, "", sizeof(buffer));

    /* printf("\nPlease enter the decimal year or calendar date\n (YYYY.yyy, MM DD YYYY or MM/DD/YYYY):\n");
    while (NULL == fgets(buffer, sizeof(buffer), stdin)) {
        printf("\nPlease enter the decimal year or calendar date\n (YYYY.yyy, MM DD YYYY or MM/DD/YYYY):\n");
    } */

    strncpy(buffer, argv[4], sizeof(buffer));

    for(i = 0, done = 0; i < sizeof(buffer) && !done; i++)
    {
        if(buffer[i] == '.')
        {
            j = sscanf(buffer, "%lf", &MagneticDate->DecimalYear);
            if(j == 1)
                done = 1;
            else
                buffer[i] = '\0';
        }
        if(buffer[i] == '/')
        {
            sscanf(buffer, "%d/%d/%d", &MagneticDate->Month, &MagneticDate->Day, &MagneticDate->Year);
            if(!MAG_DateToYear(MagneticDate, Error_Message))
            {
                printf("%s", Error_Message);
                printf("\nPlease re-enter Date in MM/DD/YYYY or MM DD YYYY format, or as a decimal year\n");
                while (NULL == fgets(buffer, sizeof(buffer), stdin)) {
                    printf("\nPlease re-enter Date in MM/DD/YYYY or MM DD YYYY format, or as a decimal year\n");
                    if (buffer[sizeof(buffer) - 1] != '\n'){
                        MAG_clear_input_buffer(); // Remove the left characters from stdin if the buffer is not able to read the whole stdin
                    }
                }
                 
                i = 0;
            } else
                done = 1;
        }
        if((i < sizeof(buffer) - 1 && buffer[i] == ' ' && buffer[i + 1] != '/') || buffer[i] == '\0')
        {
            if(3 == sscanf(buffer, "%d %d %d", &a, &b, &c))
            {
                MagneticDate->Month = a;
                MagneticDate->Day = b;
                MagneticDate->Year = c;
                MagneticDate->DecimalYear = 99999;
            } else if(1 == sscanf(buffer, "%d %d %d", &a, &b, &c))
            {
                MagneticDate->DecimalYear = a;
                done = 1;
            }
            if(!(MagneticDate->DecimalYear == a))
            {
                if(!MAG_DateToYear(MagneticDate, Error_Message))
                {
                    printf("%s", Error_Message);
                    MAG_strlcpy_equivalent(buffer, "", sizeof(buffer));
                    printf("\nError encountered, please re-enter Date in MM/DD/YYYY or MM DD YYYY format, or as a decimal year\n");
                    while( NULL== fgets(buffer, sizeof(buffer), stdin)){
                        printf("\nError encountered, please re-enter Date in MM/DD/YYYY or MM DD YYYY format, or as a decimal year\n");
                        if (buffer[strlen(buffer) - 1] != '\n') {
                            MAG_clear_input_buffer(); 
                        }
                    }
                    
                    i = -1;
                } else
                    done = 1;
            }
        }
        if(buffer[i] == '\0' && i != -1 && done != 1)
        {
            MAG_strlcpy_equivalent(buffer, "", sizeof(buffer));
            printf("\nError encountered, please re-enter as MM/DD/YYYY, MM DD YYYY, or as YYYY.yyy:\n");
            while (NULL ==fgets(buffer, sizeof(buffer), stdin)) {
                printf("\nError encountered, please re-enter as MM/DD/YYYY, MM DD YYYY, or as YYYY.yyy:\n"); 
                if (buffer[sizeof(buffer) - 1] != '\n'){
                    MAG_clear_input_buffer(); // Remove the left characters from stdin if the buffer is not able to read the whole stdin
                }
            }
             
            i = -1;
        }
        if(done)
        {
            if(MagneticDate->DecimalYear > MagneticModel->CoefficientFileEndDate || MagneticDate->DecimalYear < MagneticModel->min_year)
            {
                switch(MAG_Warnings(4, MagneticDate->DecimalYear, MagneticModel)) {
                    case 0:
                        return 0;
                    case 1:
                        done = 0;
                        i = -1;
                        MAG_strlcpy_equivalent(buffer, "", sizeof(buffer));
                        printf("\nPlease enter the decimal year or calendar date\n (YYYY.yyy, MM DD YYYY or MM/DD/YYYY):\n");
                        while(NULL == fgets(buffer, sizeof(buffer), stdin)){
                            printf("\nPlease enter the decimal year or calendar date\n (YYYY.yyy, MM DD YYYY or MM/DD/YYYY):\n");
                            if (buffer[sizeof(buffer) - 1] != '\n'){
                                MAG_clear_input_buffer(); // Remove the left characters from stdin if the buffer is not able to read the whole stdin
                            }
                        }
                         
                        break;
                    case 2:
                        break;
                }
            }
        }
    }
    free(Qstring);
    return TRUE;
} /*MAG_GetUserInputCLI*/
