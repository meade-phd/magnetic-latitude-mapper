/*	WMM Subroutine library was tested in the following environments
 *
 *	1. Red Hat Linux  with GCC Compiler
 *	2. MS Windows XP with CodeGear C++ compiler
 *	3. Sun Solaris with GCC Compiler
 *
 *
 *      Revision Number: $Revision: 1437 $
 *      Last changed by: $Author: Li-Yin Young $
 *      Last changed on: $Date: 2024-11-08 10:49:40 -0700 $
 *
 *
 */

#include "GeomagnetismHeader.h"


#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE
#endif

/*
 #ifndef EPOCHRANGE
 #define EPOCHRANGE (int)5
 #endif
*/

#ifndef GEOMAGHEADERCLI_H
#define GEOMAGHEADERCLI_H

void MAG_PrintUserDataWithUncertaintyCLI(MAGtype_GeoMagneticElements GeomagElements,
        MAGtype_GeoMagneticElements Errors,
        MAGtype_CoordGeodetic SpaceInput,
        MAGtype_Date TimeInput,
        MAGtype_MagneticModel *MagneticModel,
        MAGtype_Geoid *Geoid,
        int oneline);

#endif /*GEOMAGHEADERCLI_H*/
